package ar.org.centro35.curso.app.web;

import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {
        String mensaje="<h1>Servidor de Carlos</h1>";

        //TODO HTTP Response

        try (ServerSocket ss=new ServerSocket(8000)) {
            while (true) {
                System.out.println("Esperando conexión .....");
                try (
                        Socket so=ss.accept();
                        OutputStream out=so.getOutputStream();
                    ) {
                    System.out.println("se conecto: "+so.getInetAddress());
                    out.write(mensaje.getBytes());
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
